package cpm.com.lenovotraining.xmlgettersetter;

public class CoverageBean
{
	protected int MID;
	
	protected String storeId;
	protected String merchanId;
	protected String dataSource;
	protected String davId;
	
	protected String coverageReamark;

	protected String training_mode_cd;
	protected String managed;

	public String getCoverageReamark() {
		return coverageReamark;
	}

	public void setCoverageReamark(String coverageReamark) {
		this.coverageReamark = coverageReamark;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public String getDavId() {
		return davId;
	}

	public void setDavId(String davId) {
		this.davId = davId;
	}

	public String getMerchanId() {
		return merchanId;
	}

	public void setMerchanId(String merchanId) {
		this.merchanId = merchanId;
	}

	protected String image1;
	protected String selfieImage;
	public String getSelfieImage() {
		return selfieImage;
	}

	public void setSelfieImage(String selfieImage) {
		this.selfieImage = selfieImage;
	}

	protected String image2;
	protected String remarkis;
	protected String coveargestatus;
	public String getCoveargestatus() {
		return coveargestatus;
	}

	public void setCoveargestatus(String coveargestatus) {
		this.coveargestatus = coveargestatus;
	}

	public String getRemarkis() {
		return remarkis;
	}

	public void setRemarkis(String remarkis) {
		this.remarkis = remarkis;
	}

	public String getImage1() {
		return image1;
	}

	public void setImage1(String image1) {
		this.image1 = image1;
	}

	public String getImage2() {
		return image2;
	}

	public void setImage2(String image2) {
		this.image2 = image2;
	}

	protected String Remark;
	
	public String getRemark() {
		return Remark;
	}

	public void setRemark(String remark) {
		Remark = remark;
	}

	protected String userId;
	
	protected String inTime;
	
	protected String outTime;
	
	protected String visitDate;
	
	protected String keycontactId;
	
	protected String isdDeploy;
	
	protected String uploadStatus;
	
	private String latitude;
	
	private String longitude;
	
	private String reasonid="";
	
	private String sub_reasonId="";
	
	public String getSub_reasonId() {
		return sub_reasonId;
	}

	public void setSub_reasonId(String sub_reasonId) {
		this.sub_reasonId = sub_reasonId;
	}

	private String reason="";
	
	private String status="N";
	
	private String image="";
	

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getMID() {
		return MID;
	}

	public void setMID(int mID) {
		MID = mID;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getInTime() {
		return inTime;
	}

	public void setInTime(String inTime) {
		this.inTime = inTime;
	}

	public String getOutTime() {
		return outTime;
	}

	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}

	public String getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}

	public String getKeycontactId() {
		return keycontactId;
	}

	public void setKeycontactId(String keycontactId) {
		this.keycontactId = keycontactId;
	}

	public String getIsdDeploy() {
		return isdDeploy;
	}

	public void setIsdDeploy(String isdDeploy) {
		this.isdDeploy = isdDeploy;
	}

	public String getUploadStatus() {
		return uploadStatus;
	}

	public void setUploadStatus(String uploadStatus) {
		this.uploadStatus = uploadStatus;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getReasonid() {
		return reasonid;
	}

	public void setReasonid(String reasonid) {
		this.reasonid = reasonid;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getTraining_mode_cd() {
		return training_mode_cd;
	}

	public void setTraining_mode_cd(String training_mode_cd) {
		this.training_mode_cd = training_mode_cd;
	}

	public String getManaged() {
		return managed;
	}

	public void setManaged(String managed) {
		this.managed = managed;
	}
}
