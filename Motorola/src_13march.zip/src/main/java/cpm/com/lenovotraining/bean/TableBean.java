package cpm.com.lenovotraining.bean;

/**
 * Created by yadavendras on 21-06-2016.
 */
public class TableBean {

    public static String table_jcp;
    public static String table_trainig_topic;
    public static String table_store_isd;
    public static String table_quiz_question;
    public static String table_audit_checklist;
    public static String table_todays_quiz;
    public static String table_non_working;
    public static String table_isd_performance;

    public static String table_reason_attendance;

    public static String getTable_jcp() {
        return table_jcp;
    }

    public static void setTable_jcp(String table_jcp) {
        TableBean.table_jcp = table_jcp;
    }

    public static String getTable_trainig_topic() {
        return table_trainig_topic;
    }

    public static void setTable_trainig_topic(String table_trainig_topic) {
        TableBean.table_trainig_topic = table_trainig_topic;
    }

    public static String getTable_store_isd() {
        return table_store_isd;
    }

    public static void setTable_store_isd(String table_store_isd) {
        TableBean.table_store_isd = table_store_isd;
    }

    public static String getTable_quiz_question() {
        return table_quiz_question;
    }

    public static void setTable_quiz_question(String table_quiz_question) {
        TableBean.table_quiz_question = table_quiz_question;
    }

    public static String getTable_audit_checklist() {
        return table_audit_checklist;
    }

    public static void setTable_audit_checklist(String table_audit_checklist) {
        TableBean.table_audit_checklist = table_audit_checklist;
    }

    public static String getTable_todays_quiz() {
        return table_todays_quiz;
    }

    public static void setTable_todays_quiz(String table_todays_quiz) {
        TableBean.table_todays_quiz = table_todays_quiz;
    }

    public static String getTable_non_working() {
        return table_non_working;
    }

    public static void setTable_non_working(String table_non_working) {
        TableBean.table_non_working = table_non_working;
    }

    public static String getTable_isd_performance() {
        return table_isd_performance;
    }

    public static void setTable_isd_performance(String table_isd_performance) {
        TableBean.table_isd_performance = table_isd_performance;
    }

    public static String getTable_reason_attendance() {
        return table_reason_attendance;
    }

    public static void setTable_reason_attendance(String table_reason_attendance) {
        TableBean.table_reason_attendance = table_reason_attendance;
    }
}
