package cpm.com.lenovotraining.xmlgettersetter;

/**
 * Created by yadavendras on 31-08-2016.
 */
public class ImageDataGetterSetter {

    String store_id, path;
}
