package cpm.com.lenovotraining.xmlgettersetter;

/**
 * Created by yadavendras on 14-09-2016.
 */
public class AllIsdNEmployeeGetterSetter {

    String type, isd_cd, name, topic;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIsd_cd() {
        return isd_cd;
    }

    public void setIsd_cd(String isd_cd) {
        this.isd_cd = isd_cd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }
}
