package cpm.com.lenovotraining.xmlgettersetter;

/**
 * Created by yadavendras on 17-06-2016.
 */
public class FailureGetterSetter {

    private String status="",errorMsg;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }


}
